var searchData=
[
  ['total_0',['Total',['../struct_d3_d12_m_a_1_1_total_statistics.html#ac0bb53579457ddec2872c547ae8922a6',1,'D3D12MA::TotalStatistics']]]
];
