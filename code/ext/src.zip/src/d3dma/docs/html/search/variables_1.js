var searchData=
[
  ['block_0',['block',['../class_d3_d12_m_a_1_1_allocation.html#a413aec64eba9f4ec57e912511591b3b8',1,'D3D12MA::Allocation']]],
  ['blockbytes_1',['BlockBytes',['../struct_d3_d12_m_a_1_1_statistics.html#a65557893f80ff116c43965dbd8d45812',1,'D3D12MA::Statistics']]],
  ['blockcount_2',['BlockCount',['../struct_d3_d12_m_a_1_1_statistics.html#a780b0ddd26d8f6b033ddaa3ba436bf65',1,'D3D12MA::Statistics']]],
  ['blocksize_3',['BlockSize',['../struct_d3_d12_m_a_1_1_p_o_o_l___d_e_s_c.html#af7284cc51a8ed5b551075584256de23c',1,'D3D12MA::POOL_DESC']]],
  ['budgetbytes_4',['BudgetBytes',['../struct_d3_d12_m_a_1_1_budget.html#a326515f08d89ee2e31dcfdd5c1e8ac71',1,'D3D12MA::Budget']]],
  ['bytesfreed_5',['BytesFreed',['../struct_d3_d12_m_a_1_1_d_e_f_r_a_g_m_e_n_t_a_t_i_o_n___s_t_a_t_s.html#a7ed1bf228f39989ff3419ce3f50002c9',1,'D3D12MA::DEFRAGMENTATION_STATS']]],
  ['bytesmoved_6',['BytesMoved',['../struct_d3_d12_m_a_1_1_d_e_f_r_a_g_m_e_n_t_a_t_i_o_n___s_t_a_t_s.html#adc4c36df302a6b320443a4a33a3e31c8',1,'D3D12MA::DEFRAGMENTATION_STATS']]]
];
