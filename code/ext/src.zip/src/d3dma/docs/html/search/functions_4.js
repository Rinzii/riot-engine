var searchData=
[
  ['freeallocation_0',['FreeAllocation',['../class_d3_d12_m_a_1_1_virtual_block.html#aab44e46bd122054c894fc84740f1e8fb',1,'D3D12MA::VirtualBlock']]],
  ['freestatsstring_1',['FreeStatsString',['../class_d3_d12_m_a_1_1_allocator.html#a8392663494384c16d8bfa12b827b4f9c',1,'D3D12MA::Allocator::FreeStatsString()'],['../class_d3_d12_m_a_1_1_virtual_block.html#a6f78ddaa7da194e239089e52093e68a9',1,'D3D12MA::VirtualBlock::FreeStatsString()']]]
];
