var searchData=
[
  ['begindefragmentation_0',['BeginDefragmentation',['../class_d3_d12_m_a_1_1_pool.html#adc87bb49c192de8f5a9ca0484c499575',1,'D3D12MA::Pool::BeginDefragmentation()'],['../class_d3_d12_m_a_1_1_allocator.html#a08e1468f1dbb63ce3bf6680e592b2143',1,'D3D12MA::Allocator::BeginDefragmentation()']]],
  ['beginpass_1',['BeginPass',['../class_d3_d12_m_a_1_1_defragmentation_context.html#a1606c015d02edc094bb246986159d592',1,'D3D12MA::DefragmentationContext']]],
  ['buildstatsstring_2',['BuildStatsString',['../class_d3_d12_m_a_1_1_allocator.html#a29716b3084916abed7793bf2ec4b65db',1,'D3D12MA::Allocator::BuildStatsString()'],['../class_d3_d12_m_a_1_1_virtual_block.html#a828a27070bfa762cae796d4c8f2ef703',1,'D3D12MA::VirtualBlock::BuildStatsString()']]]
];
