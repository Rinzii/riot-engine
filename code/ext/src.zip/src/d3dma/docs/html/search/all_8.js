var searchData=
[
  ['iscachecoherentuma_0',['IsCacheCoherentUMA',['../class_d3_d12_m_a_1_1_allocator.html#a08210561b92c4bd7ede9dd7beba4bb80',1,'D3D12MA::Allocator']]],
  ['isempty_1',['IsEmpty',['../class_d3_d12_m_a_1_1_virtual_block.html#a7b23fd2da6f0343095fb14b31395678b',1,'D3D12MA::VirtualBlock']]],
  ['isuma_2',['IsUMA',['../class_d3_d12_m_a_1_1_allocator.html#a9e742884bd45dd7f01193d13fcd05af0',1,'D3D12MA::Allocator']]]
];
