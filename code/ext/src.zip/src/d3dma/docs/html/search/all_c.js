var searchData=
[
  ['offset_0',['Offset',['../struct_d3_d12_m_a_1_1_v_i_r_t_u_a_l___a_l_l_o_c_a_t_i_o_n___i_n_f_o.html#aa125871ef3fcc8af81fc831cd386dc2e',1,'D3D12MA::VIRTUAL_ALLOCATION_INFO']]],
  ['operation_1',['Operation',['../struct_d3_d12_m_a_1_1_d_e_f_r_a_g_m_e_n_t_a_t_i_o_n___m_o_v_e.html#a5ba8d6894267ae59df4efb9972af5d81',1,'D3D12MA::DEFRAGMENTATION_MOVE']]]
];
