var searchData=
[
  ['virtual_20allocator_0',['Virtual allocator',['../virtual_allocator.html',1,'index']]]
];
