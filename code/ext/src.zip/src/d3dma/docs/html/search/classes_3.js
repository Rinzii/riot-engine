var searchData=
[
  ['pool_0',['Pool',['../class_d3_d12_m_a_1_1_pool.html',1,'D3D12MA']]],
  ['pool_5fdesc_1',['POOL_DESC',['../struct_d3_d12_m_a_1_1_p_o_o_l___d_e_s_c.html',1,'D3D12MA']]]
];
