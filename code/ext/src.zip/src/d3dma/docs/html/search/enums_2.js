var searchData=
[
  ['pool_5fflags_0',['POOL_FLAGS',['../namespace_d3_d12_m_a.html#a919d8545365d6b7209a964f2b99936d1',1,'D3D12MA']]]
];
