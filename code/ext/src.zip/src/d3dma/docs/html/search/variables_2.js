var searchData=
[
  ['custompool_0',['CustomPool',['../struct_d3_d12_m_a_1_1_a_l_l_o_c_a_t_i_o_n___d_e_s_c.html#ab06b85f3cf3254f855b29264477e3934',1,'D3D12MA::ALLOCATION_DESC']]]
];
