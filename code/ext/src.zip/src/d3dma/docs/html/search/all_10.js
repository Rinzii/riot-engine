var searchData=
[
  ['setallocationprivatedata_0',['SetAllocationPrivateData',['../class_d3_d12_m_a_1_1_virtual_block.html#ab96e34500b75a83a09d73b4585669114',1,'D3D12MA::VirtualBlock']]],
  ['setcurrentframeindex_1',['SetCurrentFrameIndex',['../class_d3_d12_m_a_1_1_allocator.html#a468ba0c93121eaaee402b08775f1dd11',1,'D3D12MA::Allocator']]],
  ['setname_2',['SetName',['../class_d3_d12_m_a_1_1_allocation.html#af9e643276b577aa7f21937f75d4b82ac',1,'D3D12MA::Allocation::SetName()'],['../class_d3_d12_m_a_1_1_pool.html#a20617cfec0461cf8c2b92115b5140c5b',1,'D3D12MA::Pool::SetName()']]],
  ['setprivatedata_3',['SetPrivateData',['../class_d3_d12_m_a_1_1_allocation.html#a6f209094455dd876b6d9f84076ee1436',1,'D3D12MA::Allocation']]],
  ['setresource_4',['SetResource',['../class_d3_d12_m_a_1_1_allocation.html#a414a088c22bae0f29b1038f5f9346d14',1,'D3D12MA::Allocation']]],
  ['size_5',['Size',['../struct_d3_d12_m_a_1_1_v_i_r_t_u_a_l___b_l_o_c_k___d_e_s_c.html#ac56491679f276a5a9956ed99bc4654e4',1,'D3D12MA::VIRTUAL_BLOCK_DESC::Size()'],['../struct_d3_d12_m_a_1_1_v_i_r_t_u_a_l___a_l_l_o_c_a_t_i_o_n___d_e_s_c.html#a976b649e45abdd0769da0d79acde4bac',1,'D3D12MA::VIRTUAL_ALLOCATION_DESC::Size()'],['../struct_d3_d12_m_a_1_1_v_i_r_t_u_a_l___a_l_l_o_c_a_t_i_o_n___i_n_f_o.html#ac265159500190e35ebef8e4784c73a09',1,'D3D12MA::VIRTUAL_ALLOCATION_INFO::Size()']]],
  ['statistics_6',['Statistics',['../struct_d3_d12_m_a_1_1_statistics.html',1,'D3D12MA::Statistics'],['../statistics.html',1,'index']]],
  ['stats_7',['Stats',['../struct_d3_d12_m_a_1_1_detailed_statistics.html#a2490d4a08a5d47c87a699001dfc8737f',1,'D3D12MA::DetailedStatistics::Stats()'],['../struct_d3_d12_m_a_1_1_budget.html#a1255508930766db238cfb1312b15f1cf',1,'D3D12MA::Budget::Stats()']]]
];
