var searchData=
[
  ['d3d12_20memory_20allocator_0',['D3D12 Memory Allocator',['../index.html',1,'']]],
  ['defragmentation_1',['Defragmentation',['../defragmentation.html',1,'index']]]
];
