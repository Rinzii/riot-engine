var searchData=
[
  ['free_5ffunc_5fptr_0',['FREE_FUNC_PTR',['../namespace_d3_d12_m_a.html#a8aec93527f98fae7e42a7cd35a3ae9b1',1,'D3D12MA']]]
];
