var searchData=
[
  ['virtual_5fallocation_5fdesc_0',['VIRTUAL_ALLOCATION_DESC',['../struct_d3_d12_m_a_1_1_v_i_r_t_u_a_l___a_l_l_o_c_a_t_i_o_n___d_e_s_c.html',1,'D3D12MA']]],
  ['virtual_5fallocation_5finfo_1',['VIRTUAL_ALLOCATION_INFO',['../struct_d3_d12_m_a_1_1_v_i_r_t_u_a_l___a_l_l_o_c_a_t_i_o_n___i_n_f_o.html',1,'D3D12MA']]],
  ['virtual_5fblock_5fdesc_2',['VIRTUAL_BLOCK_DESC',['../struct_d3_d12_m_a_1_1_v_i_r_t_u_a_l___b_l_o_c_k___d_e_s_c.html',1,'D3D12MA']]],
  ['virtualallocation_3',['VirtualAllocation',['../struct_d3_d12_m_a_1_1_virtual_allocation.html',1,'D3D12MA']]],
  ['virtualblock_4',['VirtualBlock',['../class_d3_d12_m_a_1_1_virtual_block.html',1,'D3D12MA']]]
];
