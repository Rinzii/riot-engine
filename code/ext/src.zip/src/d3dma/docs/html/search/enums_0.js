var searchData=
[
  ['allocation_5fflags_0',['ALLOCATION_FLAGS',['../namespace_d3_d12_m_a.html#abbad31a7e0b3d09d77f3fb704b77645e',1,'D3D12MA']]],
  ['allocator_5fflags_1',['ALLOCATOR_FLAGS',['../namespace_d3_d12_m_a.html#ad5ae5a5e42b878f2e18ab5d1fbfb9916',1,'D3D12MA']]]
];
