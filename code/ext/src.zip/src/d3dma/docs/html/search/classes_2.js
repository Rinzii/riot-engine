var searchData=
[
  ['defragmentation_5fdesc_0',['DEFRAGMENTATION_DESC',['../struct_d3_d12_m_a_1_1_d_e_f_r_a_g_m_e_n_t_a_t_i_o_n___d_e_s_c.html',1,'D3D12MA']]],
  ['defragmentation_5fmove_1',['DEFRAGMENTATION_MOVE',['../struct_d3_d12_m_a_1_1_d_e_f_r_a_g_m_e_n_t_a_t_i_o_n___m_o_v_e.html',1,'D3D12MA']]],
  ['defragmentation_5fpass_5fmove_5finfo_2',['DEFRAGMENTATION_PASS_MOVE_INFO',['../struct_d3_d12_m_a_1_1_d_e_f_r_a_g_m_e_n_t_a_t_i_o_n___p_a_s_s___m_o_v_e___i_n_f_o.html',1,'D3D12MA']]],
  ['defragmentation_5fstats_3',['DEFRAGMENTATION_STATS',['../struct_d3_d12_m_a_1_1_d_e_f_r_a_g_m_e_n_t_a_t_i_o_n___s_t_a_t_s.html',1,'D3D12MA']]],
  ['defragmentationcontext_4',['DefragmentationContext',['../class_d3_d12_m_a_1_1_defragmentation_context.html',1,'D3D12MA']]],
  ['detailedstatistics_5',['DetailedStatistics',['../struct_d3_d12_m_a_1_1_detailed_statistics.html',1,'D3D12MA']]]
];
