var searchData=
[
  ['createallocator_0',['CreateAllocator',['../class_d3_d12_m_a_1_1_allocator.html#a458f044fdc81e4a0b147e99ffcf73459',1,'D3D12MA::Allocator']]],
  ['createvirtualblock_1',['CreateVirtualBlock',['../class_d3_d12_m_a_1_1_virtual_block.html#a0485028cbe13b5457fe422865f7edf74',1,'D3D12MA::VirtualBlock']]]
];
