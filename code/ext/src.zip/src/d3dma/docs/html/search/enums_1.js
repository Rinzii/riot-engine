var searchData=
[
  ['defragmentation_5fflags_0',['DEFRAGMENTATION_FLAGS',['../namespace_d3_d12_m_a.html#ab433989212ee6736bf9d63c5bc565df4',1,'D3D12MA']]],
  ['defragmentation_5fmove_5foperation_1',['DEFRAGMENTATION_MOVE_OPERATION',['../namespace_d3_d12_m_a.html#a82bb787a69699a877b4166789a30e602',1,'D3D12MA']]]
];
