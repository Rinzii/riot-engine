var searchData=
[
  ['unusedrangecount_0',['UnusedRangeCount',['../struct_d3_d12_m_a_1_1_detailed_statistics.html#aff1aaecbb86eedfdb15c1b11987ac0d9',1,'D3D12MA::DetailedStatistics']]],
  ['unusedrangesizemax_1',['UnusedRangeSizeMax',['../struct_d3_d12_m_a_1_1_detailed_statistics.html#a5fae01864d6e6595cb9c416a9f365e7c',1,'D3D12MA::DetailedStatistics']]],
  ['unusedrangesizemin_2',['UnusedRangeSizeMin',['../struct_d3_d12_m_a_1_1_detailed_statistics.html#ac13f6cb1737f0d906e55182385f38b70',1,'D3D12MA::DetailedStatistics']]],
  ['usagebytes_3',['UsageBytes',['../struct_d3_d12_m_a_1_1_budget.html#a77a8c9e32d6602f95b7d1c285cddd253',1,'D3D12MA::Budget']]]
];
