var searchData=
[
  ['residencypriority_0',['ResidencyPriority',['../struct_d3_d12_m_a_1_1_p_o_o_l___d_e_s_c.html#a2e6074af8c8ff7b957fe8d4b5036a5e6',1,'D3D12MA::POOL_DESC']]]
];
