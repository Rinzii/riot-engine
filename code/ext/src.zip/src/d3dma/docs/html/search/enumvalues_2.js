var searchData=
[
  ['pool_5fflag_5falgorithm_5flinear_0',['POOL_FLAG_ALGORITHM_LINEAR',['../namespace_d3_d12_m_a.html#a919d8545365d6b7209a964f2b99936d1aa37a0103f511954ea42a1d0bba286b6a',1,'D3D12MA']]],
  ['pool_5fflag_5falgorithm_5fmask_1',['POOL_FLAG_ALGORITHM_MASK',['../namespace_d3_d12_m_a.html#a919d8545365d6b7209a964f2b99936d1aec9d4939b8cc5438545b9df840b5f5f7',1,'D3D12MA']]],
  ['pool_5fflag_5fmsaa_5ftextures_5falways_5fcommitted_2',['POOL_FLAG_MSAA_TEXTURES_ALWAYS_COMMITTED',['../namespace_d3_d12_m_a.html#a919d8545365d6b7209a964f2b99936d1acc379a89755438c0f76667783b778baa',1,'D3D12MA']]],
  ['pool_5fflag_5fnone_3',['POOL_FLAG_NONE',['../namespace_d3_d12_m_a.html#a919d8545365d6b7209a964f2b99936d1a5d8dc91add3423140809a550c7224d02',1,'D3D12MA']]]
];
