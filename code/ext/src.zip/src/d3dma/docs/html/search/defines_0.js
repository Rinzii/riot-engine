var searchData=
[
  ['d3d12ma_5fdxgi_5f1_5f4_0',['D3D12MA_DXGI_1_4',['../_d3_d12_mem_alloc_8h.html#aa623643886b8481adb32017e5c748b50',1,'D3D12MemAlloc.h']]],
  ['d3d12ma_5fuse_5fsmall_5fresource_5fplacement_5falignment_1',['D3D12MA_USE_SMALL_RESOURCE_PLACEMENT_ALIGNMENT',['../_d3_d12_mem_alloc_8h.html#ad04069a2e2bbc53b7d65f85a04a2dcbc',1,'D3D12MemAlloc.h']]]
];
