var searchData=
[
  ['setallocationprivatedata_0',['SetAllocationPrivateData',['../class_d3_d12_m_a_1_1_virtual_block.html#ab96e34500b75a83a09d73b4585669114',1,'D3D12MA::VirtualBlock']]],
  ['setcurrentframeindex_1',['SetCurrentFrameIndex',['../class_d3_d12_m_a_1_1_allocator.html#a468ba0c93121eaaee402b08775f1dd11',1,'D3D12MA::Allocator']]],
  ['setname_2',['SetName',['../class_d3_d12_m_a_1_1_allocation.html#af9e643276b577aa7f21937f75d4b82ac',1,'D3D12MA::Allocation::SetName()'],['../class_d3_d12_m_a_1_1_pool.html#a20617cfec0461cf8c2b92115b5140c5b',1,'D3D12MA::Pool::SetName()']]],
  ['setprivatedata_3',['SetPrivateData',['../class_d3_d12_m_a_1_1_allocation.html#a6f209094455dd876b6d9f84076ee1436',1,'D3D12MA::Allocation']]],
  ['setresource_4',['SetResource',['../class_d3_d12_m_a_1_1_allocation.html#a414a088c22bae0f29b1038f5f9346d14',1,'D3D12MA::Allocation']]]
];
