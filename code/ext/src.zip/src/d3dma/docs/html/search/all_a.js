var searchData=
[
  ['m_5fcommitted_0',['m_Committed',['../class_d3_d12_m_a_1_1_allocation.html#a5b3d5b189021973d9934cbe9f5f266f0',1,'D3D12MA::Allocation']]],
  ['m_5fheap_1',['m_Heap',['../class_d3_d12_m_a_1_1_allocation.html#adc7cf6224b7ca6205d1099a013f40424',1,'D3D12MA::Allocation']]],
  ['m_5fplaced_2',['m_Placed',['../class_d3_d12_m_a_1_1_allocation.html#a35fca5f0b1c5eb46d0bb33cdb7ccc198',1,'D3D12MA::Allocation']]],
  ['maxallocationsperpass_3',['MaxAllocationsPerPass',['../struct_d3_d12_m_a_1_1_d_e_f_r_a_g_m_e_n_t_a_t_i_o_n___d_e_s_c.html#a83bfb404f387863eafdd6703483aed89',1,'D3D12MA::DEFRAGMENTATION_DESC']]],
  ['maxblockcount_4',['MaxBlockCount',['../struct_d3_d12_m_a_1_1_p_o_o_l___d_e_s_c.html#abbce3a99f253928f9c3c09fa16015f9e',1,'D3D12MA::POOL_DESC']]],
  ['maxbytesperpass_5',['MaxBytesPerPass',['../struct_d3_d12_m_a_1_1_d_e_f_r_a_g_m_e_n_t_a_t_i_o_n___d_e_s_c.html#ad8d224e0687a35898970d0a5688c6343',1,'D3D12MA::DEFRAGMENTATION_DESC']]],
  ['memorysegmentgroup_6',['MemorySegmentGroup',['../struct_d3_d12_m_a_1_1_total_statistics.html#aed7d22d5cd773aa896bc4c786c7f3650',1,'D3D12MA::TotalStatistics']]],
  ['minallocationalignment_7',['MinAllocationAlignment',['../struct_d3_d12_m_a_1_1_p_o_o_l___d_e_s_c.html#a0a6283eeb1f3f99d8c4ae264aec7f749',1,'D3D12MA::POOL_DESC']]],
  ['minblockcount_8',['MinBlockCount',['../struct_d3_d12_m_a_1_1_p_o_o_l___d_e_s_c.html#a6f10db3911a3bea1becfc9a0dfa5bac8',1,'D3D12MA::POOL_DESC']]],
  ['movecount_9',['MoveCount',['../struct_d3_d12_m_a_1_1_d_e_f_r_a_g_m_e_n_t_a_t_i_o_n___p_a_s_s___m_o_v_e___i_n_f_o.html#a8df22d990c318d82fe9fcc5f04132c04',1,'D3D12MA::DEFRAGMENTATION_PASS_MOVE_INFO']]]
];
