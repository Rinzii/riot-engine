var searchData=
[
  ['getalignment_0',['GetAlignment',['../class_d3_d12_m_a_1_1_allocation.html#a0acdc6b31e957b6d83762bdaace6d255',1,'D3D12MA::Allocation']]],
  ['getallocationinfo_1',['GetAllocationInfo',['../class_d3_d12_m_a_1_1_virtual_block.html#ac605dce05ca0d411e46079f0bad765d1',1,'D3D12MA::VirtualBlock']]],
  ['getbudget_2',['GetBudget',['../class_d3_d12_m_a_1_1_allocator.html#a1ac113daec5f6ef28ecb1786cf544144',1,'D3D12MA::Allocator']]],
  ['getd3d12options_3',['GetD3D12Options',['../class_d3_d12_m_a_1_1_allocator.html#ae276d2358a58a36f8c6639f837f29be5',1,'D3D12MA::Allocator']]],
  ['getdesc_4',['GetDesc',['../class_d3_d12_m_a_1_1_pool.html#aaab59af46d922d6b81fce8d8be987028',1,'D3D12MA::Pool']]],
  ['getheap_5',['GetHeap',['../class_d3_d12_m_a_1_1_allocation.html#adca8d5a82bed492fe7265fcda6e53da2',1,'D3D12MA::Allocation']]],
  ['getmemorycapacity_6',['GetMemoryCapacity',['../class_d3_d12_m_a_1_1_allocator.html#a434ae3147209953253da26687bfd62dc',1,'D3D12MA::Allocator']]],
  ['getname_7',['GetName',['../class_d3_d12_m_a_1_1_allocation.html#a65fab0c479df1b6b72c9300e68dc6770',1,'D3D12MA::Allocation::GetName()'],['../class_d3_d12_m_a_1_1_pool.html#a63c91d92a9ca48b98866a5cc1aea333b',1,'D3D12MA::Pool::GetName()']]],
  ['getoffset_8',['GetOffset',['../class_d3_d12_m_a_1_1_allocation.html#a47be9557d441797b65de177a3d5cdf60',1,'D3D12MA::Allocation']]],
  ['getprivatedata_9',['GetPrivateData',['../class_d3_d12_m_a_1_1_allocation.html#ae45eed901de5d16afe179f883028c5ee',1,'D3D12MA::Allocation']]],
  ['getresource_10',['GetResource',['../class_d3_d12_m_a_1_1_allocation.html#ad00308118252f82d8f803c623c67bf18',1,'D3D12MA::Allocation']]],
  ['getsize_11',['GetSize',['../class_d3_d12_m_a_1_1_allocation.html#a92c2fb6f22b28817eb83a59407d7dd30',1,'D3D12MA::Allocation']]],
  ['getstatistics_12',['GetStatistics',['../class_d3_d12_m_a_1_1_pool.html#aa9d849dc4667314b2a53eddf02f5af91',1,'D3D12MA::Pool::GetStatistics()'],['../class_d3_d12_m_a_1_1_virtual_block.html#a0f1dda0e019e218b021f64987a74b110',1,'D3D12MA::VirtualBlock::GetStatistics()']]],
  ['getstats_13',['GetStats',['../class_d3_d12_m_a_1_1_defragmentation_context.html#a1c21c26f47dcbf8f4e562063a3e25f38',1,'D3D12MA::DefragmentationContext']]]
];
