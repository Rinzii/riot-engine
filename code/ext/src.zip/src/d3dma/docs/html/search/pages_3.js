var searchData=
[
  ['linear_20allocation_20algorithm_0',['Linear allocation algorithm',['../linear_algorithm.html',1,'index']]]
];
