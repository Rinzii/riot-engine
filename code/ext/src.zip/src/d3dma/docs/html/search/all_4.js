var searchData=
[
  ['endpass_0',['EndPass',['../class_d3_d12_m_a_1_1_defragmentation_context.html#aad502ba70d6dadaeee37703fd8bf90ae',1,'D3D12MA::DefragmentationContext']]],
  ['extraheapflags_1',['ExtraHeapFlags',['../struct_d3_d12_m_a_1_1_a_l_l_o_c_a_t_i_o_n___d_e_s_c.html#a97878838f976b2d1e6b1a76881035690',1,'D3D12MA::ALLOCATION_DESC']]]
];
