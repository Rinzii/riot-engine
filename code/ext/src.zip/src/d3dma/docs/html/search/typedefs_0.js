var searchData=
[
  ['allocate_5ffunc_5fptr_0',['ALLOCATE_FUNC_PTR',['../namespace_d3_d12_m_a.html#a8bcc49af3c53bbe04dbcb41c093dce58',1,'D3D12MA']]],
  ['allochandle_1',['AllocHandle',['../namespace_d3_d12_m_a.html#a15e349adce86a40e0417d405aef1af80',1,'D3D12MA']]]
];
