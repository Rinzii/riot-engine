var searchData=
[
  ['heap_0',['heap',['../class_d3_d12_m_a_1_1_allocation.html#a4e7380aabcac5b0a1cd833c5c84459c6',1,'D3D12MA::Allocation']]],
  ['heapflags_1',['HeapFlags',['../struct_d3_d12_m_a_1_1_p_o_o_l___d_e_s_c.html#a3795956e4fbfe7c3a23546e02e5d28dc',1,'D3D12MA::POOL_DESC']]],
  ['heapproperties_2',['HeapProperties',['../struct_d3_d12_m_a_1_1_p_o_o_l___d_e_s_c.html#a06e06813bcb5206e9f7a8b0564bf1d6a',1,'D3D12MA::POOL_DESC']]],
  ['heapsfreed_3',['HeapsFreed',['../struct_d3_d12_m_a_1_1_d_e_f_r_a_g_m_e_n_t_a_t_i_o_n___s_t_a_t_s.html#aecc6120afcf75028c9850f8d475b727d',1,'D3D12MA::DEFRAGMENTATION_STATS']]],
  ['heaptype_4',['HeapType',['../struct_d3_d12_m_a_1_1_a_l_l_o_c_a_t_i_o_n___d_e_s_c.html#aa46b3c0456e5a23edef3328607ebf4d7',1,'D3D12MA::ALLOCATION_DESC::HeapType()'],['../struct_d3_d12_m_a_1_1_total_statistics.html#a07247152fc70a8ee5605cab0fe220ea5',1,'D3D12MA::TotalStatistics::HeapType()']]]
];
