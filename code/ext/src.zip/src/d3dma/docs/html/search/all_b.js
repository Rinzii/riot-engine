var searchData=
[
  ['next_0',['next',['../class_d3_d12_m_a_1_1_allocation.html#a6f31560bc71451410a2a907b6d81b48f',1,'D3D12MA::Allocation']]]
];
