var searchData=
[
  ['size_0',['Size',['../struct_d3_d12_m_a_1_1_v_i_r_t_u_a_l___b_l_o_c_k___d_e_s_c.html#ac56491679f276a5a9956ed99bc4654e4',1,'D3D12MA::VIRTUAL_BLOCK_DESC::Size()'],['../struct_d3_d12_m_a_1_1_v_i_r_t_u_a_l___a_l_l_o_c_a_t_i_o_n___d_e_s_c.html#a976b649e45abdd0769da0d79acde4bac',1,'D3D12MA::VIRTUAL_ALLOCATION_DESC::Size()'],['../struct_d3_d12_m_a_1_1_v_i_r_t_u_a_l___a_l_l_o_c_a_t_i_o_n___i_n_f_o.html#ac265159500190e35ebef8e4784c73a09',1,'D3D12MA::VIRTUAL_ALLOCATION_INFO::Size()']]],
  ['stats_1',['Stats',['../struct_d3_d12_m_a_1_1_detailed_statistics.html#a2490d4a08a5d47c87a699001dfc8737f',1,'D3D12MA::DetailedStatistics::Stats()'],['../struct_d3_d12_m_a_1_1_budget.html#a1255508930766db238cfb1312b15f1cf',1,'D3D12MA::Budget::Stats()']]]
];
