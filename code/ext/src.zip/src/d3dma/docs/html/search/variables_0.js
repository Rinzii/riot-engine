var searchData=
[
  ['alignment_0',['Alignment',['../struct_d3_d12_m_a_1_1_v_i_r_t_u_a_l___a_l_l_o_c_a_t_i_o_n___d_e_s_c.html#aaa95e62f2f399339a09dcbb312a42de0',1,'D3D12MA::VIRTUAL_ALLOCATION_DESC']]],
  ['allocationbytes_1',['AllocationBytes',['../struct_d3_d12_m_a_1_1_statistics.html#a53cfe3d241124b5a8e8058871a4b50e8',1,'D3D12MA::Statistics']]],
  ['allocationcount_2',['AllocationCount',['../struct_d3_d12_m_a_1_1_statistics.html#aef88ac53531db43a8888ad2be4a06c68',1,'D3D12MA::Statistics']]],
  ['allocationsizemax_3',['AllocationSizeMax',['../struct_d3_d12_m_a_1_1_detailed_statistics.html#a2f47015bebf9a30ce221aef88fe11991',1,'D3D12MA::DetailedStatistics']]],
  ['allocationsizemin_4',['AllocationSizeMin',['../struct_d3_d12_m_a_1_1_detailed_statistics.html#a187e5562265c3daa87c15d54f1396a6a',1,'D3D12MA::DetailedStatistics']]],
  ['allocationsmoved_5',['AllocationsMoved',['../struct_d3_d12_m_a_1_1_d_e_f_r_a_g_m_e_n_t_a_t_i_o_n___s_t_a_t_s.html#a708fa1b14c35da8d5d6abd4a457ef0c2',1,'D3D12MA::DEFRAGMENTATION_STATS']]],
  ['allochandle_6',['allocHandle',['../class_d3_d12_m_a_1_1_allocation.html#a5c38846905b1ca0ff228c6081f2fc20c',1,'D3D12MA::Allocation']]],
  ['allochandle_7',['AllocHandle',['../struct_d3_d12_m_a_1_1_virtual_allocation.html#a5d3166cf1f284fbbea4d0b169c4dba13',1,'D3D12MA::VirtualAllocation']]]
];
