var searchData=
[
  ['extraheapflags_0',['ExtraHeapFlags',['../struct_d3_d12_m_a_1_1_a_l_l_o_c_a_t_i_o_n___d_e_s_c.html#a97878838f976b2d1e6b1a76881035690',1,'D3D12MA::ALLOCATION_DESC']]]
];
