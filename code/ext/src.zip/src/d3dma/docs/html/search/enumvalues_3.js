var searchData=
[
  ['virtual_5fallocation_5fflag_5fnone_0',['VIRTUAL_ALLOCATION_FLAG_NONE',['../namespace_d3_d12_m_a.html#a7e4152ccaf661f5398b24a23cbe9ae72a03576295004dec9dc8f99a895d232027',1,'D3D12MA']]],
  ['virtual_5fallocation_5fflag_5fstrategy_5fmask_1',['VIRTUAL_ALLOCATION_FLAG_STRATEGY_MASK',['../namespace_d3_d12_m_a.html#a7e4152ccaf661f5398b24a23cbe9ae72a6a78fdd4c16ef443e9353622caf7efb9',1,'D3D12MA']]],
  ['virtual_5fallocation_5fflag_5fstrategy_5fmin_5fmemory_2',['VIRTUAL_ALLOCATION_FLAG_STRATEGY_MIN_MEMORY',['../namespace_d3_d12_m_a.html#a7e4152ccaf661f5398b24a23cbe9ae72affe589cb8817363fed0d207c3a5f2ad9',1,'D3D12MA']]],
  ['virtual_5fallocation_5fflag_5fstrategy_5fmin_5foffset_3',['VIRTUAL_ALLOCATION_FLAG_STRATEGY_MIN_OFFSET',['../namespace_d3_d12_m_a.html#a7e4152ccaf661f5398b24a23cbe9ae72abd8063a364dba797e928b6aaa85dd5f0',1,'D3D12MA']]],
  ['virtual_5fallocation_5fflag_5fstrategy_5fmin_5ftime_4',['VIRTUAL_ALLOCATION_FLAG_STRATEGY_MIN_TIME',['../namespace_d3_d12_m_a.html#a7e4152ccaf661f5398b24a23cbe9ae72ae37ebe327c9d46b5ad68e5a95c888efe',1,'D3D12MA']]],
  ['virtual_5fallocation_5fflag_5fupper_5faddress_5',['VIRTUAL_ALLOCATION_FLAG_UPPER_ADDRESS',['../namespace_d3_d12_m_a.html#a7e4152ccaf661f5398b24a23cbe9ae72a86beebcb80a1a10cb5525e2c9ed1435e',1,'D3D12MA']]],
  ['virtual_5fblock_5fflag_5falgorithm_5flinear_6',['VIRTUAL_BLOCK_FLAG_ALGORITHM_LINEAR',['../namespace_d3_d12_m_a.html#a578329923a103be086ac52e3bed2085dabd9968af113acc9a756254ab9f1dc13d',1,'D3D12MA']]],
  ['virtual_5fblock_5fflag_5falgorithm_5fmask_7',['VIRTUAL_BLOCK_FLAG_ALGORITHM_MASK',['../namespace_d3_d12_m_a.html#a578329923a103be086ac52e3bed2085da0fee243cbf2902a68123ac85caa21e3e',1,'D3D12MA']]],
  ['virtual_5fblock_5fflag_5fnone_8',['VIRTUAL_BLOCK_FLAG_NONE',['../namespace_d3_d12_m_a.html#a578329923a103be086ac52e3bed2085dafc882884f8bacd5cab3087567df8c53d',1,'D3D12MA']]]
];
