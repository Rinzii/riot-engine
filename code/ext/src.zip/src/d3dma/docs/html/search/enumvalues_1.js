var searchData=
[
  ['defragmentation_5fflag_5falgorithm_5fbalanced_0',['DEFRAGMENTATION_FLAG_ALGORITHM_BALANCED',['../namespace_d3_d12_m_a.html#ab433989212ee6736bf9d63c5bc565df4ace3a84861ed6a1b8066fa9c12c7e89b9',1,'D3D12MA']]],
  ['defragmentation_5fflag_5falgorithm_5ffast_1',['DEFRAGMENTATION_FLAG_ALGORITHM_FAST',['../namespace_d3_d12_m_a.html#ab433989212ee6736bf9d63c5bc565df4a9d0301a81136ca79e3ba52542c6d2e13',1,'D3D12MA']]],
  ['defragmentation_5fflag_5falgorithm_5ffull_2',['DEFRAGMENTATION_FLAG_ALGORITHM_FULL',['../namespace_d3_d12_m_a.html#ab433989212ee6736bf9d63c5bc565df4af205647f08a5c2cddced83ed66892467',1,'D3D12MA']]],
  ['defragmentation_5fflag_5falgorithm_5fmask_3',['DEFRAGMENTATION_FLAG_ALGORITHM_MASK',['../namespace_d3_d12_m_a.html#ab433989212ee6736bf9d63c5bc565df4a567e0fe890cc07d8dd6576584e8d9f2d',1,'D3D12MA']]],
  ['defragmentation_5fmove_5foperation_5fcopy_4',['DEFRAGMENTATION_MOVE_OPERATION_COPY',['../namespace_d3_d12_m_a.html#a82bb787a69699a877b4166789a30e602a29a5c20322e633f6c34ddebd16bc61ac',1,'D3D12MA']]],
  ['defragmentation_5fmove_5foperation_5fdestroy_5',['DEFRAGMENTATION_MOVE_OPERATION_DESTROY',['../namespace_d3_d12_m_a.html#a82bb787a69699a877b4166789a30e602aa2143507d723de458c2ed94e143ac242',1,'D3D12MA']]],
  ['defragmentation_5fmove_5foperation_5fignore_6',['DEFRAGMENTATION_MOVE_OPERATION_IGNORE',['../namespace_d3_d12_m_a.html#a82bb787a69699a877b4166789a30e602abefe270a1803998dda3f8e01ec3a4ad6',1,'D3D12MA']]]
];
