var searchData=
[
  ['calculatestatistics_0',['CalculateStatistics',['../class_d3_d12_m_a_1_1_pool.html#ad07999ac5dc8f0c63187afd45d551910',1,'D3D12MA::Pool::CalculateStatistics()'],['../class_d3_d12_m_a_1_1_allocator.html#a99db00df909963573a976c203b107d22',1,'D3D12MA::Allocator::CalculateStatistics()'],['../class_d3_d12_m_a_1_1_virtual_block.html#a614a82247ce6cf29c38895e16eb971d9',1,'D3D12MA::VirtualBlock::CalculateStatistics(DetailedStatistics *pStats) const']]],
  ['clear_1',['Clear',['../class_d3_d12_m_a_1_1_virtual_block.html#ae22b18c0b7c31b44c1d740f886369189',1,'D3D12MA::VirtualBlock']]],
  ['configuration_2',['Configuration',['../configuration.html',1,'index']]],
  ['createaliasingresource_3',['CreateAliasingResource',['../class_d3_d12_m_a_1_1_allocator.html#ab45536f92410aedb7be44ea36b1b4717',1,'D3D12MA::Allocator']]],
  ['createaliasingresource1_4',['CreateAliasingResource1',['../class_d3_d12_m_a_1_1_allocator.html#ad3b83cc5707cb4ed92bc277069c4ddd6',1,'D3D12MA::Allocator']]],
  ['createaliasingresource2_5',['CreateAliasingResource2',['../class_d3_d12_m_a_1_1_allocator.html#a562cbaa71cbd333cade09cd67ed82453',1,'D3D12MA::Allocator']]],
  ['createallocator_6',['CreateAllocator',['../class_d3_d12_m_a_1_1_allocator.html#a458f044fdc81e4a0b147e99ffcf73459',1,'D3D12MA::Allocator::CreateAllocator()'],['../namespace_d3_d12_m_a.html#ab7a1cd1683986d75ce1488b0920f4cb0',1,'D3D12MA::CreateAllocator()']]],
  ['createpool_7',['CreatePool',['../class_d3_d12_m_a_1_1_allocator.html#aac7b1f6bf53cbf4c4ce2264cb72ca515',1,'D3D12MA::Allocator']]],
  ['createresource_8',['CreateResource',['../class_d3_d12_m_a_1_1_allocator.html#aa37d6b9fe8ea0864f7a35b9d68e8345a',1,'D3D12MA::Allocator']]],
  ['createresource2_9',['CreateResource2',['../class_d3_d12_m_a_1_1_allocator.html#a7a1c79c79a7a573c438aa45c4a531b96',1,'D3D12MA::Allocator']]],
  ['createresource3_10',['CreateResource3',['../class_d3_d12_m_a_1_1_allocator.html#a323b2af320b01d0fdecfc515c75db747',1,'D3D12MA::Allocator']]],
  ['createvirtualblock_11',['CreateVirtualBlock',['../class_d3_d12_m_a_1_1_virtual_block.html#a0485028cbe13b5457fe422865f7edf74',1,'D3D12MA::VirtualBlock::CreateVirtualBlock()'],['../namespace_d3_d12_m_a.html#ab024647ae85ee63e2fa2c1c4beac6d98',1,'D3D12MA::CreateVirtualBlock()']]],
  ['custom_20memory_20pools_12',['Custom memory pools',['../custom_pools.html',1,'index']]],
  ['custompool_13',['CustomPool',['../struct_d3_d12_m_a_1_1_a_l_l_o_c_a_t_i_o_n___d_e_s_c.html#ab06b85f3cf3254f855b29264477e3934',1,'D3D12MA::ALLOCATION_DESC']]]
];
