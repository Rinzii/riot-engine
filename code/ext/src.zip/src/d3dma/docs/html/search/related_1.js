var searchData=
[
  ['d3d12ma_5fdelete_0',['D3D12MA_DELETE',['../class_d3_d12_m_a_1_1_allocation.html#a968f13f23d03e50cc50b87835b6d5a85',1,'D3D12MA::Allocation::D3D12MA_DELETE()'],['../class_d3_d12_m_a_1_1_defragmentation_context.html#a968f13f23d03e50cc50b87835b6d5a85',1,'D3D12MA::DefragmentationContext::D3D12MA_DELETE()'],['../class_d3_d12_m_a_1_1_pool.html#a968f13f23d03e50cc50b87835b6d5a85',1,'D3D12MA::Pool::D3D12MA_DELETE()'],['../class_d3_d12_m_a_1_1_allocator.html#a968f13f23d03e50cc50b87835b6d5a85',1,'D3D12MA::Allocator::D3D12MA_DELETE()'],['../class_d3_d12_m_a_1_1_virtual_block.html#a968f13f23d03e50cc50b87835b6d5a85',1,'D3D12MA::VirtualBlock::D3D12MA_DELETE()']]]
];
