var searchData=
[
  ['allocate_0',['Allocate',['../class_d3_d12_m_a_1_1_virtual_block.html#a9281daf76e888ea1bd5247d5732e8179',1,'D3D12MA::VirtualBlock']]],
  ['allocatememory_1',['AllocateMemory',['../class_d3_d12_m_a_1_1_allocator.html#acb8a10a5ea30171ce60128286aec5ee2',1,'D3D12MA::Allocator']]]
];
