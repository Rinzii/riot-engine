var searchData=
[
  ['totalstatistics_0',['TotalStatistics',['../struct_d3_d12_m_a_1_1_total_statistics.html',1,'D3D12MA']]]
];
