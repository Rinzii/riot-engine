var searchData=
[
  ['allocation_0',['Allocation',['../class_d3_d12_m_a_1_1_allocation.html',1,'D3D12MA']]],
  ['allocation_5fcallbacks_1',['ALLOCATION_CALLBACKS',['../struct_d3_d12_m_a_1_1_a_l_l_o_c_a_t_i_o_n___c_a_l_l_b_a_c_k_s.html',1,'D3D12MA']]],
  ['allocation_5fdesc_2',['ALLOCATION_DESC',['../struct_d3_d12_m_a_1_1_a_l_l_o_c_a_t_i_o_n___d_e_s_c.html',1,'D3D12MA']]],
  ['allocator_3',['Allocator',['../class_d3_d12_m_a_1_1_allocator.html',1,'D3D12MA']]],
  ['allocator_5fdesc_4',['ALLOCATOR_DESC',['../struct_d3_d12_m_a_1_1_a_l_l_o_c_a_t_o_r___d_e_s_c.html',1,'D3D12MA']]]
];
