var searchData=
[
  ['padapter_0',['pAdapter',['../struct_d3_d12_m_a_1_1_a_l_l_o_c_a_t_o_r___d_e_s_c.html#abf9a9f87f0ffea52816efd363c5fcd7b',1,'D3D12MA::ALLOCATOR_DESC']]],
  ['pallocate_1',['pAllocate',['../struct_d3_d12_m_a_1_1_a_l_l_o_c_a_t_i_o_n___c_a_l_l_b_a_c_k_s.html#af4d6436455728696fefd503869226436',1,'D3D12MA::ALLOCATION_CALLBACKS']]],
  ['pallocationcallbacks_2',['pAllocationCallbacks',['../struct_d3_d12_m_a_1_1_a_l_l_o_c_a_t_o_r___d_e_s_c.html#a773ecc1945eb47c20e06455c3759e4ef',1,'D3D12MA::ALLOCATOR_DESC::pAllocationCallbacks()'],['../struct_d3_d12_m_a_1_1_v_i_r_t_u_a_l___b_l_o_c_k___d_e_s_c.html#aa8ea08ad0ee64cb2d29c03b85008317f',1,'D3D12MA::VIRTUAL_BLOCK_DESC::pAllocationCallbacks()']]],
  ['pdevice_3',['pDevice',['../struct_d3_d12_m_a_1_1_a_l_l_o_c_a_t_o_r___d_e_s_c.html#ada1bf21205065b3aa0284b5a9ee1cb3c',1,'D3D12MA::ALLOCATOR_DESC']]],
  ['pdsttmpallocation_4',['pDstTmpAllocation',['../struct_d3_d12_m_a_1_1_d_e_f_r_a_g_m_e_n_t_a_t_i_o_n___m_o_v_e.html#aec0c7f51ccc870c6a88af7c7390d8eda',1,'D3D12MA::DEFRAGMENTATION_MOVE']]],
  ['pfree_5',['pFree',['../struct_d3_d12_m_a_1_1_a_l_l_o_c_a_t_i_o_n___c_a_l_l_b_a_c_k_s.html#a114e6c4d63d6b020e01f526a975d6849',1,'D3D12MA::ALLOCATION_CALLBACKS']]],
  ['pmoves_6',['pMoves',['../struct_d3_d12_m_a_1_1_d_e_f_r_a_g_m_e_n_t_a_t_i_o_n___p_a_s_s___m_o_v_e___i_n_f_o.html#a719fbdaae54251759605c41baeb24dc4',1,'D3D12MA::DEFRAGMENTATION_PASS_MOVE_INFO']]],
  ['pprivatedata_7',['pPrivateData',['../struct_d3_d12_m_a_1_1_a_l_l_o_c_a_t_i_o_n___c_a_l_l_b_a_c_k_s.html#a98173cc9e239a84c2ce369854966e1e3',1,'D3D12MA::ALLOCATION_CALLBACKS::pPrivateData()'],['../struct_d3_d12_m_a_1_1_a_l_l_o_c_a_t_i_o_n___d_e_s_c.html#ac638dd987f1326e2fdab91892d994d35',1,'D3D12MA::ALLOCATION_DESC::pPrivateData()'],['../struct_d3_d12_m_a_1_1_v_i_r_t_u_a_l___a_l_l_o_c_a_t_i_o_n___d_e_s_c.html#aa1281297154e3823e98a7cc7e23b5d6b',1,'D3D12MA::VIRTUAL_ALLOCATION_DESC::pPrivateData()'],['../struct_d3_d12_m_a_1_1_v_i_r_t_u_a_l___a_l_l_o_c_a_t_i_o_n___i_n_f_o.html#a05c258ea40ea47667ddcc395b13a47a5',1,'D3D12MA::VIRTUAL_ALLOCATION_INFO::pPrivateData()']]],
  ['pprotectedsession_8',['pProtectedSession',['../struct_d3_d12_m_a_1_1_p_o_o_l___d_e_s_c.html#a475840ec05c19732c8d5aa8bb27270f4',1,'D3D12MA::POOL_DESC']]],
  ['preferredblocksize_9',['PreferredBlockSize',['../struct_d3_d12_m_a_1_1_a_l_l_o_c_a_t_o_r___d_e_s_c.html#a97149c9559deae943c2cfa49aeeff8a6',1,'D3D12MA::ALLOCATOR_DESC']]],
  ['prev_10',['prev',['../class_d3_d12_m_a_1_1_allocation.html#adc3ac89758a915a409e047f9b89aa160',1,'D3D12MA::Allocation']]],
  ['psrcallocation_11',['pSrcAllocation',['../struct_d3_d12_m_a_1_1_d_e_f_r_a_g_m_e_n_t_a_t_i_o_n___m_o_v_e.html#a4946b874c958a71c21fac25b515cf5f7',1,'D3D12MA::DEFRAGMENTATION_MOVE']]]
];
