var searchData=
[
  ['virtual_5fallocation_5fflags_0',['VIRTUAL_ALLOCATION_FLAGS',['../namespace_d3_d12_m_a.html#a7e4152ccaf661f5398b24a23cbe9ae72',1,'D3D12MA']]],
  ['virtual_5fblock_5fflags_1',['VIRTUAL_BLOCK_FLAGS',['../namespace_d3_d12_m_a.html#a578329923a103be086ac52e3bed2085d',1,'D3D12MA']]]
];
