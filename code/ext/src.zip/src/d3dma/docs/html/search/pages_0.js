var searchData=
[
  ['configuration_0',['Configuration',['../configuration.html',1,'index']]],
  ['custom_20memory_20pools_1',['Custom memory pools',['../custom_pools.html',1,'index']]]
];
